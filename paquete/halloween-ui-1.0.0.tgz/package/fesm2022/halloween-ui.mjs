import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.imagen = "";
		this.titulo = "";
		this.texto = "";
		this.textoBoton = "Ver más";
		this.botonPulsado = new EventEmitter();
	}
	pulsarBoton() {
		this.botonPulsado.emit();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.3",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.3",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				imagen: "imagen",
				titulo: "titulo",
				texto: "texto",
				textoBoton: "textoBoton"
			},
			outputs: { botonPulsado: "botonPulsado" },
			ngImport: i0,
			template: "<div class=\"tarjeta\">\n  <img class=\"imagen\" [src]=\"imagen\" [alt]=\"titulo\" />\n\n  <div class=\"contenido\">\n    <h2 class=\"titulo\">{{ titulo }}</h2>\n    <p class=\"texto\">{{ texto }}</p>\n    <button class=\"boton\" (click)=\"pulsarBoton()\">🦇 {{ textoBoton }}</button>\n  </div>\n</div>\n",
			styles: [":host{display:block}.tarjeta{margin:16px;background-color:#1a0a12;border:4px double #8b0000;border-radius:12px;box-shadow:0 0 15px #8b0000;color:#fff;overflow:hidden;transition:transform .3s,box-shadow .3s}.tarjeta:hover{transform:translateY(-5px);box-shadow:0 0 25px #dc143c}.imagen{width:100%;max-height:220px;object-fit:cover;display:block;border-bottom:2px solid #8b0000}.contenido{padding:16px;text-align:center}.titulo{font-family:Creepster,Georgia,serif;color:#dc143c;font-size:28px;margin:0 0 10px}.texto{font-family:Georgia,serif;font-size:16px;line-height:1.5;margin-bottom:16px}.boton{background-color:#8b0000;color:#fff;border:2px solid #c9a227;border-radius:20px;padding:10px 20px;font-size:16px;cursor:pointer}.boton:hover{background-color:#b30000}.boton:active{transform:scale(.9)}.imagen{width:100%;height:220px;object-fit:contain;background-color:#000;display:block;border-bottom:2px solid #8b0000}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			imports: [],
			template: "<div class=\"tarjeta\">\n  <img class=\"imagen\" [src]=\"imagen\" [alt]=\"titulo\" />\n\n  <div class=\"contenido\">\n    <h2 class=\"titulo\">{{ titulo }}</h2>\n    <p class=\"texto\">{{ texto }}</p>\n    <button class=\"boton\" (click)=\"pulsarBoton()\">🦇 {{ textoBoton }}</button>\n  </div>\n</div>\n",
			styles: [":host{display:block}.tarjeta{margin:16px;background-color:#1a0a12;border:4px double #8b0000;border-radius:12px;box-shadow:0 0 15px #8b0000;color:#fff;overflow:hidden;transition:transform .3s,box-shadow .3s}.tarjeta:hover{transform:translateY(-5px);box-shadow:0 0 25px #dc143c}.imagen{width:100%;max-height:220px;object-fit:cover;display:block;border-bottom:2px solid #8b0000}.contenido{padding:16px;text-align:center}.titulo{font-family:Creepster,Georgia,serif;color:#dc143c;font-size:28px;margin:0 0 10px}.texto{font-family:Georgia,serif;font-size:16px;line-height:1.5;margin-bottom:16px}.boton{background-color:#8b0000;color:#fff;border:2px solid #c9a227;border-radius:20px;padding:10px 20px;font-size:16px;cursor:pointer}.boton:hover{background-color:#b30000}.boton:active{transform:scale(.9)}.imagen{width:100%;height:220px;object-fit:contain;background-color:#000;display:block;border-bottom:2px solid #8b0000}\n"]
		}]
	}],
	propDecorators: {
		imagen: [{ type: Input }],
		titulo: [{ type: Input }],
		texto: [{ type: Input }],
		textoBoton: [{ type: Input }],
		botonPulsado: [{ type: Output }]
	}
});
export { MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map