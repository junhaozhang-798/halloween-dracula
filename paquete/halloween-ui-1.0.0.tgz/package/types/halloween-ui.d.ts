import * as i0 from "@angular/core";
import { EventEmitter } from "@angular/core";
export declare class MonsterCardComponent {
  imagen: string;
  titulo: string;
  texto: string;
  textoBoton: string;
  botonPulsado: EventEmitter<void>;
  pulsarBoton(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, {
    "imagen": {
      "alias": "imagen";
      "required": false;
    };
    "titulo": {
      "alias": "titulo";
      "required": false;
    };
    "texto": {
      "alias": "texto";
      "required": false;
    };
    "textoBoton": {
      "alias": "textoBoton";
      "required": false;
    };
  }, {
    "botonPulsado": "botonPulsado";
  }, never, never, true, never>;
}